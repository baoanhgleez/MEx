/** Automatically generated file. DO NOT MODIFY */
package test_ssh_raspberry.tho;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}